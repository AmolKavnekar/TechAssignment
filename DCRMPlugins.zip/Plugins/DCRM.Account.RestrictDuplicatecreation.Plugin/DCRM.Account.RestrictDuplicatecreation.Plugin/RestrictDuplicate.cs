﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Startek.CRM.Plugin.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCRM.Account.RestrictDuplicatecreation.Plugin
{
    public class RestrictDuplicate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            IOrganizationServiceFactory servicefactory =
             (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service =
            servicefactory.CreateOrganizationService(context.UserId);

            #region Duplicate Detection Logic
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                if (entity.LogicalName != "account")
                {
                    return;
                }
               
                try
                {
                    string address = string.Empty;
                    string name = string.Empty;
                    if (entity.Attributes.Contains("address1_postalcode"))
                    {
                         address = entity.GetAttributeValue<string>("address1_postalcode").ToString();
                        tracingService.Trace("address : " + address);
                       
                    }
                    if (entity.Attributes.Contains("name"))
                    {
                         name = entity.GetAttributeValue<string>("name").ToString();
                        tracingService.Trace("name : " + name);
                    }
                    if (address !=null || name !=null)
	                {
		                // Fetching the records with same name and Address
                        string fetchXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                           <entity name='account'>
                                            <attribute name='name' />
                                            <attribute name='primarycontactid' />
                                            <attribute name='telephone1' />
                                            <attribute name='accountid' />
                                            <attribute name='address1_postalcode' />
                                            <order attribute='name' descending='false' />
                                            <filter type='and'> 
                                              <condition attribute='name' operator='eq' value='" + name + @"' />
                                              <condition attribute='address1_postalcode' operator='eq' value='" + address +@"' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                        tracingService.Trace("Fetch Xml : " + fetchXML);
                        EntityCollection entityCollection = service.RetrieveMultiple(new FetchExpression(fetchXML));
                        tracingService.Trace("record" + entityCollection.Entities.Count);
                    
                        if(entityCollection.Entities.Count > 0)
                        {
                            throw new InvalidPluginExecutionException($"Account with the same Name and Address is already Present.");
                        } 
	                }

                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException (ex.Message);
                }
            }
            #endregion
        }
    }
}
