﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;

namespace Startek.CRM.Plugin.Common
{
    public static class CommonService
    {
        #region CRM extension methods

        internal static Entity RetriveEntity(IOrganizationService service, Microsoft.Xrm.Sdk.Workflow.IWorkflowContext context)
        {
            return service.Retrieve(context.PrimaryEntityName, context.PrimaryEntityId, new ColumnSet(true));
        }

        internal static Entity RetriveEntity(IOrganizationService service, string entityName, Guid entityId, string[] columns)
        {
            return service.Retrieve(entityName, entityId, new ColumnSet(columns));
        }

        internal static Entity RetriveEntity(IOrganizationService service, string entityName, Guid entityId, bool allColumns)
        {
            return service.Retrieve(entityName, entityId, new ColumnSet(allColumns));
        }

        #endregion CRM extension methods

        internal static string HtmlToPlainText(string html)
        {
            const string tagWhiteSpace = @"(>|$)(\W|\n|\r)+<";//matches one or more (white space or line breaks) between '>' and '<'
            const string stripFormatting = @"<[^>]*(>|$)";//match any character between '<' and '>', even when end tag is missing
            const string lineBreak = @"<(br|BR)\s{0,1}\/{0,1}>";//matches: <br>,<br/>,<br />,<BR>,<BR/>,<BR />
            var lineBreakRegex = new Regex(lineBreak, RegexOptions.Multiline);
            var stripFormattingRegex = new Regex(stripFormatting, RegexOptions.Multiline);
            var tagWhiteSpaceRegex = new Regex(tagWhiteSpace, RegexOptions.Multiline);

            var text = html;
            //Decode html specific characters
            text = WebUtility.HtmlDecode(text);
            //Remove tag whitespace/line breaks
            text = tagWhiteSpaceRegex.Replace(text, "><");
            //Replace <br /> with line breaks
            text = lineBreakRegex.Replace(text, Environment.NewLine);
            //Strip formatting
            text = stripFormattingRegex.Replace(text, string.Empty);

            return text;
        }

        #region api call json request

        internal class CustomWebClient : WebClient
        {
            // Overrides the GetWebRequest method and sets keep alive to false
            protected override WebRequest GetWebRequest(Uri address)
            {
                HttpWebRequest req = (HttpWebRequest)base.GetWebRequest(address);
                req.KeepAlive = false;

                return req;
            }
        }

        public static string Apicall(string url, string jsonobject)
        {
            using (var client = new CustomWebClient())
            {
                client.Headers[HttpRequestHeader.ContentType] = "application/json";

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                var serviceUrl = url;
                var response = client.UploadString(serviceUrl, jsonobject);
                return response;
            }
        }

        public static string ApiPostCall(string url, string authText, string jsonObject)
        {
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            //httpWebRequest.Headers.Add("Authorization", "Basic " + SecretAPIKey);
            if (!string.IsNullOrEmpty(authText))
                httpWebRequest.Headers.Add("Authorization", authText);

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            using (Stream stream = httpWebRequest.GetRequestStream())
            {
                UTF8Encoding encoding = new UTF8Encoding();
                byte[] bytes = encoding.GetBytes(jsonObject);
                stream.Write(bytes, 0, bytes.Length);
            }
            using (HttpWebResponse httpResponse = (HttpWebResponse)httpWebRequest.GetResponse())
            {
                using (Stream stream = httpResponse.GetResponseStream())
                {
                    return (new StreamReader(stream)).ReadToEnd();
                }
            }
        }

        #endregion api call json request

        internal static T JsonToListConversion<T>(string dataType)
        {
            using (var deSerializememoryStream = new MemoryStream())
            {
                //Json String that we get from web api
                //initialize DataContractJsonSerializer object and pass Student class type to it
                var serializer = new DataContractJsonSerializer(typeof(T));

                //user stream writer to write JSON string data to memory stream
                var writer = new StreamWriter(deSerializememoryStream);
                writer.Write(dataType);
                writer.Flush();

                deSerializememoryStream.Position = 0;
                //get the Desrialized data in object of type Student
                var serializedObject = (T)serializer.ReadObject(deSerializememoryStream);
                return serializedObject;
            }
        }

        internal static int? GetOptionSetValue(IOrganizationService _organizationService, string entityName, string attributeName, string optionsetText)
        {
            int? optionSetValue = null;
            var retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName,
                RetrieveAsIfPublished = true
            };

            var retrieveAttributeResponse =
                (RetrieveAttributeResponse)_organizationService.Execute(retrieveAttributeRequest);
            var picklistAttributeMetadata =
                (PicklistAttributeMetadata)retrieveAttributeResponse.AttributeMetadata;

            var optionsetMetadata = picklistAttributeMetadata.OptionSet;

            foreach (var optionMetadata in optionsetMetadata.Options)
                if (optionMetadata.Label.UserLocalizedLabel.Label.ToLower() == optionsetText.ToLower())
                {
                    if (optionMetadata.Value != null) optionSetValue = optionMetadata.Value.Value;
                    return optionSetValue;
                }
            return null;
        }

        public static string GetOptionSetValueLabel(IOrganizationService organizationService, string entityName, string fieldName, int optionSetValue)
        {
            var attReq = new RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = fieldName,
                RetrieveAsIfPublished = true
            };

            var attResponse = (RetrieveAttributeResponse)organizationService.Execute(attReq);
            var attMetadata = (EnumAttributeMetadata)attResponse.AttributeMetadata;

            return attMetadata.OptionSet.Options.Where(x => x.Value == optionSetValue).FirstOrDefault().Label.UserLocalizedLabel.Label;
        }

        /// <summary>
        /// To log c# object into JSON string using tracing service
        /// </summary>
        /// <param name="tracingService"></param>
        /// <param name="TitleText"></param>
        /// <param name="objectValue"></param>
        /// <returns></returns>
        public static string LogJSON(ITracingService tracingService, string TitleText, object objectValue)
        {
            string JSON = JsonConvert.SerializeObject(objectValue);
            tracingService.Trace($"\n{TitleText}: {JSON}");
            return JSON;
        }

        #region BPF Processes

        public static void SwitchBPFProcess(IOrganizationService organizationService, Guid workFlowId, Entity entity)
        {
            SetProcessRequest request = new SetProcessRequest
            {
                Target = new EntityReference(entity.LogicalName, entity.Id),
                NewProcess = new EntityReference("workflow", workFlowId)
            };
            organizationService.Execute(request);
        }

        public static string GetActiveStage(IOrganizationService _organizationService, Entity entity)
        {
            RetrieveProcessInstancesRequest procLeadReq = new RetrieveProcessInstancesRequest
            {
                EntityId = entity.Id,
                EntityLogicalName = entity.LogicalName
            };
            var procLeadRes = (RetrieveProcessInstancesResponse)_organizationService.Execute(procLeadReq);

            // Declare variables to store values returned in response
            if (procLeadRes.Processes.Entities.Count > 0)
            {
                var activeProcessInstance = procLeadRes.Processes.Entities[0];
                var processLeadId = activeProcessInstance.Id;
                // Id of the active process instance, which will be used, 
                // later to retrieve the active path of the process instance
                // Retrieve the active stage ID of the active process instance

                var activeStageId = new Guid(activeProcessInstance.Attributes["processstageid"].ToString());
                // Retrieve the process stages in the active path of the current process instance
                var pathReq = new RetrieveActivePathRequest
                {
                    ProcessInstanceId = processLeadId
                };
                var pathResp = (RetrieveActivePathResponse)_organizationService.Execute(pathReq);

                for (int i = 0; i < pathResp.ProcessStages.Entities.Count; i++)
                {
                    // Retrieve the active stage name and active stage position based on the activeStageId for the process instance
                    if (pathResp.ProcessStages.Entities[i].Attributes["processstageid"].ToString() == activeStageId.ToString())
                    {
                        var activeStageName = pathResp.ProcessStages.Entities[i].Attributes["stagename"].ToString();
                        return activeStageName;
                    }
                }
            }
            return null;
        }

        public static Guid GetActiveBPF(IOrganizationService _organizationService, Entity entity)
        {
            RetrieveProcessInstancesRequest procLeadReq = new RetrieveProcessInstancesRequest
            {
                EntityId = entity.Id,
                EntityLogicalName = entity.LogicalName
            };
            var procLeadRes = (RetrieveProcessInstancesResponse)_organizationService.Execute(procLeadReq);

            // Declare variables to store values returned in response
            if (procLeadRes.Processes.Entities.Count > 0)
            {
                var activeProcessInstance = procLeadRes.Processes.Entities[0];
                var processLeadId = activeProcessInstance.Id; // Id of the active process instance, which will be used
                                                              // later to retrieve the active path of the process instance
                                                              // Retrieve the active stage ID of the active process instance
                return processLeadId;
            }
            return Guid.Empty;
        }

        public static string SetActiveStage(IOrganizationService _organizationService, Entity entity, string stageName)
        {
            RetrieveProcessInstancesRequest procLeadReq = new RetrieveProcessInstancesRequest
            {
                EntityId = entity.Id,
                EntityLogicalName = entity.LogicalName
            };
            var procLeadRes = (RetrieveProcessInstancesResponse)_organizationService.Execute(procLeadReq);

            // Declare variables to store values returned in response
            if (procLeadRes.Processes.Entities.Count > 0)
            {
                var activeProcessInstance = procLeadRes.Processes.Entities[0];
                var processLeadId = activeProcessInstance.Id;
                // Id of the active process instance, which will be used, 
                // later to retrieve the active path of the process instance
                // Retrieve the active stage ID of the active process instance

                var activeStageId = activeProcessInstance.GetAttributeValue<Guid>("businessprocessflowinstanceid");
                // Retrieve the process stages in the active path of the current process instance
                var pathReq = new RetrieveActivePathRequest
                {
                    ProcessInstanceId = processLeadId
                };
                var pathResp = (RetrieveActivePathResponse)_organizationService.Execute(pathReq);
                Guid stageId = new Guid();
                foreach (var item in pathResp.ProcessStages.Entities)
                {
                    var _stage = item.Attributes["stagename"].ToString();
                    if (_stage == stageName)
                    {
                        stageId = (Guid)item.Attributes["processstageid"];
                        break;
                    }
                }

                Entity retrievedProcessInstance = new Entity("phonetocaseprocess");
                retrievedProcessInstance["activestageid"] = new EntityReference("processstage", stageId);
                retrievedProcessInstance.Id = activeStageId;
                _organizationService.Update(retrievedProcessInstance);
            }
            return null;
        }

        #endregion
    }

    public enum SLAStatus
    {
        InProgress = 0,
        Noncompliant = 1,
        NearingNoncompliance = 2,
        Paused = 3,
        Succeeded = 4,
        Canceled = 5
    }

    public enum CrmStateCode
    {
        Active = 0,
        Inactive = 1
    }

    public enum CrmStatusReason
    {
        Active = 1,
        Inactive = 2
    }
}